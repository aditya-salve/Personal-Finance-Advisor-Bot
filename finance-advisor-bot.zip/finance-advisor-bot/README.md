# Personal Finance Advisor Bot

AI-powered personal finance assistant: log income and expenses by category, then let **Gemini** generate a
personalised **budget plan**, **saving suggestions** and a **monthly summary report**.

**Stack:** Flask · SQLAlchemy (SQLite) · Google Gemini API · Jinja2 · Gunicorn
**Security:** API keys/secrets live in `.env` / environment variables (git-ignored); passwords are hashed.

## Features
- Register / login (per-user data)
- Monthly income tracking (multiple sources, good for freelancers)
- Daily expense logging by category (rent, food, transport, groceries, utilities, education, healthcare...)
- Dashboard: income vs spent vs saved, category breakdown
- Financial goal setting
- Gemini-generated budget plan, saving tips, monthly report (auto-fallback to 50/30/20 rule if no key/API error)

## Hardware requirements
- Processor: Intel Core i5 (8th Gen+) / AMD Ryzen 5 or equivalent
- RAM: 8 GB minimum (16 GB recommended for multitasking and AWS Labs)
- Storage: 256 GB SSD (or 500 GB HDD minimum)
- Internet: stable, 10 Mbps minimum (20 Mbps recommended for AWS Labs and deployments)

## Software requirements
- OS: Windows 10/11, macOS Monterey+, or Ubuntu 20.04+
- Browser: latest Chrome, Firefox or Edge
- IDE: Visual Studio Code (recommended)
- Git (latest), Python 3.8+, AWS CLI (latest)

## Run locally
```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # then add your GEMINI_API_KEY (free at https://aistudio.google.com/apikey)
python app.py                   # open http://127.0.0.1:5000
```

## Deploy on AWS (Elastic Beanstalk)
```bash
aws configure
pip install awsebcli
eb init -p python-3.11 finance-advisor-bot --region ap-south-1
eb create finance-advisor-env
eb setenv SECRET_KEY=<random> GEMINI_API_KEY=<key>
eb open
```
Elastic Beanstalk uses the included `Procfile` (gunicorn). For production use RDS and set `DATABASE_URL`.

## Push to GitHub
```bash
git init && git add . && git commit -m "Personal Finance Advisor Bot"
git branch -M main
git remote add origin https://github.com/<you>/finance-advisor-bot.git
git push -u origin main
```

## Project structure
```
app.py            Flask app, models, routes, Gemini integration
templates/        base, auth, dashboard
requirements.txt  .env.example  Procfile  .gitignore
```

## Future scope
Predictive spending analytics, investment suggestions, goal-based savings tracking, financial health scoring.
