"""Personal Finance Advisor Bot - Flask + SQLAlchemy + Gemini API."""
import os, json, requests
from datetime import date
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv

load_dotenv()  # secure key management: secrets come from environment, never from code
app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-change-me")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", "sqlite:///finance.db")
db = SQLAlchemy(app)

CATEGORIES = ["Rent", "Food", "Transport", "Entertainment", "Utilities",
              "Education", "Healthcare", "Groceries", "Other"]


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    goal = db.Column(db.String(255), default="")


class Income(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    source = db.Column(db.String(80), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    month = db.Column(db.String(7), nullable=False)  # YYYY-MM


class Expense(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    category = db.Column(db.String(40), nullable=False)
    note = db.Column(db.String(120), default="")
    amount = db.Column(db.Float, nullable=False)
    day = db.Column(db.Date, nullable=False)


def login_required(f):
    @wraps(f)
    def wrap(*a, **k):
        if "uid" not in session:
            return redirect(url_for("login"))
        return f(*a, **k)
    return wrap


def month_data(uid, month):
    y, m = map(int, month.split("-"))
    start = date(y, m, 1)
    end = date(y + (m == 12), (m % 12) + 1, 1)
    incomes = Income.query.filter_by(user_id=uid, month=month).all()
    expenses = Expense.query.filter(Expense.user_id == uid, Expense.day >= start,
                                    Expense.day < end).order_by(Expense.day.desc()).all()
    by_cat = {}
    for e in expenses:
        by_cat[e.category] = by_cat.get(e.category, 0) + e.amount
    inc, exp = sum(i.amount for i in incomes), sum(e.amount for e in expenses)
    return dict(incomes=incomes, expenses=expenses, by_cat=by_cat,
                income=inc, spent=exp, saved=inc - exp)


def fallback_report(d):
    """Rule-based 50/30/20 plan used when Gemini is unavailable."""
    inc = d["income"]
    plan = [{"category": "Needs (rent, food, utilities)", "limit": round(inc * .5, 2)},
            {"category": "Wants (entertainment, other)", "limit": round(inc * .3, 2)},
            {"category": "Savings", "limit": round(inc * .2, 2)}]
    tips = []
    if d["by_cat"]:
        top = max(d["by_cat"], key=d["by_cat"].get)
        tips.append(f"Your biggest expense is {top} (₹{d['by_cat'][top]:.0f}). Try trimming it by 10%.")
    tips.append("Aim to save at least 20% of income; automate a transfer on payday.")
    tips.append("Build an emergency fund covering 3-6 months of expenses.")
    return {"budget_plan": plan, "saving_suggestions": tips,
            "summary": f"Income ₹{inc:.0f}, spent ₹{d['spent']:.0f}, saved ₹{d['saved']:.0f}. (Rule-based report; add a Gemini key for AI insights.)"}


def gemini_report(d, goal, month):
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        return fallback_report(d), False
    model = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
    prompt = (
        "You are a personal finance advisor. Currency is INR. Analyse this month's data and "
        "reply ONLY with JSON: {\"budget_plan\":[{\"category\":str,\"limit\":number}],"
        "\"saving_suggestions\":[str],\"summary\":str}. Keep suggestions specific and actionable.\n"
        f"Month: {month}\nIncome: {d['income']}\nSpending by category: {json.dumps(d['by_cat'])}\n"
        f"Total spent: {d['spent']}\nSaved: {d['saved']}\nUser goal: {goal or 'none stated'}")
    try:
        r = requests.post(
            f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
            headers={"x-goog-api-key": key, "Content-Type": "application/json"},
            json={"contents": [{"parts": [{"text": prompt}]}],
                  "generationConfig": {"responseMimeType": "application/json"}}, timeout=30)
        r.raise_for_status()
        text = r.json()["candidates"][0]["content"]["parts"][0]["text"]
        return json.loads(text), True
    except Exception as ex:  # network / quota / parse errors -> graceful fallback
        app.logger.warning("Gemini failed: %s", ex)
        return fallback_report(d), False


@app.route("/")
def index():
    return redirect(url_for("dashboard") if "uid" in session else url_for("login"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        if User.query.filter_by(email=email).first():
            flash("Email already registered.")
        else:
            u = User(name=request.form["name"].strip(), email=email,
                     password_hash=generate_password_hash(request.form["password"]))
            db.session.add(u); db.session.commit()
            session["uid"] = u.id
            return redirect(url_for("dashboard"))
    return render_template("auth.html", mode="register")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = User.query.filter_by(email=request.form["email"].strip().lower()).first()
        if u and check_password_hash(u.password_hash, request.form["password"]):
            session["uid"] = u.id
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.")
    return render_template("auth.html", mode="login")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


def current_month():
    return request.values.get("month") or date.today().strftime("%Y-%m")


@app.route("/dashboard")
@login_required
def dashboard(report=None, ai=False):
    user, month = db.session.get(User, session["uid"]), current_month()
    return render_template("dashboard.html", user=user, month=month, d=month_data(user.id, month),
                           cats=CATEGORIES, report=report, ai=ai, today=date.today().isoformat())


@app.route("/income", methods=["POST"])
@login_required
def add_income():
    db.session.add(Income(user_id=session["uid"], source=request.form["source"],
                          amount=float(request.form["amount"]), month=request.form["month"]))
    db.session.commit()
    return redirect(url_for("dashboard", month=request.form["month"]))


@app.route("/expense", methods=["POST"])
@login_required
def add_expense():
    day = date.fromisoformat(request.form["day"])
    db.session.add(Expense(user_id=session["uid"], category=request.form["category"],
                           note=request.form.get("note", ""), amount=float(request.form["amount"]), day=day))
    db.session.commit()
    return redirect(url_for("dashboard", month=day.strftime("%Y-%m")))


@app.route("/expense/<int:eid>/delete", methods=["POST"])
@login_required
def delete_expense(eid):
    e = Expense.query.filter_by(id=eid, user_id=session["uid"]).first_or_404()
    month = e.day.strftime("%Y-%m")
    db.session.delete(e); db.session.commit()
    return redirect(url_for("dashboard", month=month))


@app.route("/goal", methods=["POST"])
@login_required
def set_goal():
    db.session.get(User, session["uid"]).goal = request.form["goal"][:255]
    db.session.commit()
    return redirect(url_for("dashboard", month=current_month()))


@app.route("/report", methods=["POST"])
@login_required
def report():
    user, month = db.session.get(User, session["uid"]), current_month()
    rep, ai = gemini_report(month_data(user.id, month), user.goal, month)
    return dashboard(report=rep, ai=ai)


with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(debug=os.getenv("FLASK_DEBUG") == "1")
